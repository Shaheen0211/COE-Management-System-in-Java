package coe;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
  
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Forms extends JFrame {
	static Forms frame;
	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Forms();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Forms() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setForeground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblHeader = new JLabel("SRI KRISHNA INSTITUTION");
		lblHeader.setFont(new Font("Tahoma", Font.PLAIN, 20));
		JLabel lblSubHeader = new JLabel("FORMS");
		lblSubHeader.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		JButton reval = new JButton("REVALUATION FORM");
		reval.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Reevaluation.main(new String[]{});
				frame.dispose();
			}
		});
		
		JButton btnod = new JButton("LEAVE/ON DUTY FORM");
		btnod.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				LeaveOD.main(new String[]{});
				frame.dispose();
			}
		});
		
		JButton btnnodue = new JButton("NO-DUE FORM");
		btnnodue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NoDue.main(new String[]{});
				frame.dispose();
			}
		});
		JButton btntrans = new JButton("TRANSPORT FORM");
		btntrans.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Transport.main(new String[]{});
				frame.dispose();
			}
		});
		JButton btnhos = new JButton("HOSTEL FORM");
		btnhos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Hostel.main(new String[]{});
				frame.dispose();
			}
		});
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(143)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnhos,Alignment.TRAILING,GroupLayout.DEFAULT_SIZE,GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE)
						.addComponent(btnnodue, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btntrans, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btnod, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(reval,Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)	
							.addComponent(lblSubHeader)
							.addComponent(lblHeader)))
					.addContainerGap(210, Short.MAX_VALUE))
		);
		
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblHeader)
					.addGap(42)
					.addComponent(lblSubHeader)
					.addGap(42)
					.addComponent(reval, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
					.addGap(30)
					.addComponent(btnod, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
					.addGap(30)
					.addComponent(btnnodue, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
					.addGap(30)
					.addComponent(btntrans, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
					.addGap(30)
					.addComponent(btnhos,GroupLayout.PREFERRED_SIZE,31, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(91, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
}

