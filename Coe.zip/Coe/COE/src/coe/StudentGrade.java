package coe;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class StudentGrade {
     double totalMarks;
     String grade;

    public void setTotalMarks(double totalMarks) {
        this.totalMarks = totalMarks;
        }

    public double getTotalMarks() {
        return totalMarks;
    }

    public void setGrade(String grade) {
        this.grade = grade;
        }

    public String getGrade(){
        return grade;
    }

    public static void main(String[] args){
        JLabel lab=new JLabel("Enter number of students in class: ");
        final JTextField text=new JTextField(20);

        JButton b=new JButton("Find");
        lab.setBounds(10,10,150,20);
        text.setBounds(180,10,100,20);
        b.setBounds(180,40,100,20);

        JFrame f=new JFrame();
        f.setLayout(null);
        f.add(lab);
        f.add(text);
        f.add(b);
        f.setSize(300,100);
        f.setVisible(true);
        b.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){

        int num = Integer.parseInt(text.getText());
        StudentGrade data[] = new StudentGrade[num];
        for(int a = 0; a < data.length; a++) {
           String input=JOptionPane.showInputDialog(null,"Enter student programming marks: ");

            double marks = Double.parseDouble(input);
            data[a] = new StudentGrade();
            data[a].setTotalMarks(marks);

            if (marks < 40){
                data[a].setGrade("E");
            }

            if (marks >= 40 && marks <= 44) {
                data[a].setGrade("D");
            }

            if (marks >= 45 && marks <= 49) {
                data[a].setGrade("D+");
            }

            if (marks >= 50 && marks <= 54) {
                data[a].setGrade("C-");
            }

            if (marks >= 55 && marks <= 59) {
                data[a].setGrade("C");
            }

            if (marks >= 60 && marks <= 64) {
                data[a].setGrade("C+");
            }

            if (marks >= 65 && marks <= 69) {
                data[a].setGrade("B-");
            }

            if (marks >= 70 && marks <= 74) {
                data[a].setGrade("B");
            }

            if (marks >= 75 && marks <= 79) {
                data[a].setGrade("B+");
            }

            if (marks >= 80 && marks <= 84) {
                data[a].setGrade("A");
            }

            if (marks >= 85 && marks <= 100)
                data[a].setGrade("A+");
        }

        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        int count4 = 0;
        int count5 = 0;
        int count6 = 0;
        int count7 = 0;
        int count8 = 0;
        int count9 = 0;
        int count10 = 0;
        int count11 = 0;
        for (int i = 0; i < num; i++) {
            StudentGrade show = data[i];
            String g = show.getGrade();
            if (g.equals("A+")) {
                count1++;
            }
            if (g.equals("A")) {
                count2++;
            }
            if (g.equals("B+")) {
                count3++;
            }
            if (g.equals("B")) {
                count4++;
            }
            if (g.equals("B-")){
                count5++;
            }
            if (g.equals("C+")){
                count6++;
            }
            if (g.equals("C")){
                count7++;
            }
            if (g.equals("C-")){
                count8++;
            }
            if (g.equals("D+")){
                count9++;
            }
            if (g.equals("D")){
                count10++;
            }
            if (g.equals("E")){
                count11++;
            }

        }
        JOptionPane.showMessageDialog(null,"Number of student getting A+ and A grade: "
                + (count1 + count2));
        JOptionPane.showMessageDialog(null,"Number of student getting B+ and B grade: "
                + (count3 + count4));
        JOptionPane.showMessageDialog(null,"Number of student getting A and B+ grade: "
                + (count2 + count3));
        JOptionPane.showMessageDialog(null,"Number of student getting B and B- grade: "
                + (count4 + count5));
        JOptionPane.showMessageDialog(null,"Number of student getting B- and C+ grade: "
                + (count5 + count6));
        JOptionPane.showMessageDialog(null,"Number of student getting C+ and C grade: "
                + (count6 + count7));
        JOptionPane.showMessageDialog(null,"Number of student getting C and C- grade: "
                + (count7 + count8));
        JOptionPane.showMessageDialog(null,"Number of student getting C- and D grade: "
                + (count8 + count9));
        JOptionPane.showMessageDialog(null,"Number of student getting D and D- grade: "
                + (count9 + count10));
        JOptionPane.showMessageDialog(null,"Number of student getting D- and E grade: "
                + (count10 + count11));

            }
        });
    }
}
