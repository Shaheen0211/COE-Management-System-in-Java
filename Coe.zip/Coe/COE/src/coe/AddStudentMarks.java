package coe;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;  
	import java.awt.event.ActionEvent;
		import java.awt.event.ActionListener;
		import javax.swing.JFrame;
		import javax.swing.*;
		public class AddStudentMarks extends JFrame implements ActionListener
		{
		
		JLabel l1=new JLabel("NAME");
		JLabel l2=new JLabel("ID");
		JLabel l3=new JLabel("MARKS");
		JLabel l4 =new JLabel("Sub 1 : ");
		JLabel l5 =new JLabel("Sub 2 : ");
		JLabel l6 =new JLabel("Sub 3 : ");
		JLabel l7 =new JLabel("Sub 4 : ");
		JLabel l8 =new JLabel("Sub 5 : ");
		JLabel l9 =new JLabel("Attendance : ");
		
		
		JTextField t1=new JTextField();
		JTextField t2=new JTextField();
		JTextField sub1=new JTextField();
		JTextField sub2=new JTextField();
		JTextField sub3=new JTextField();
		JTextField sub4=new JTextField();
		JTextField sub5=new JTextField();
		JTextField att=new JTextField();

		
		JButton cal=new JButton("Calculate GPA");
		JButton submit=new JButton("SUBMIT");
		//JPasswordField p=new JPasswordField();
		
		
		public AddStudentMarks()
		{
		setTitle("ADD STUDENT MARKS");
		this.setLayout(null);
		this.setVisible(true);
		this.setSize(800,800);
		l1.setBounds(100,50,50,20);
		l2.setBounds(100,100,50,20);
		l3.setBounds(200,165,50,20);
		l4.setBounds(100,200,50,20);
		l5.setBounds(100,250,50,20);
		l6.setBounds(100,300,50,20);
		l7.setBounds(100,350,50,20);
		l8.setBounds(100,400,50,20);
		l9.setBounds(200,500,100,20);
		add(l1);
		add(l2);
		add(l3);
		add(l4);
		add(l6);
		add(l5);
		add(l7);
		add(l8);
		add(l9);
		t1.setBounds(250,50,150,40);
		add(t1);
		t2.setBounds(250,100,150,40);
		add(t2);
		sub1.setBounds(250,200,150,20);
		add(sub1);
		sub2.setBounds(250,250,150,20);
		add(sub2);
		sub3.setBounds(250,300,150,20);
		add(sub3);
		sub4.setBounds(250,350,150,20);
		add(sub4);
		sub5.setBounds(250,400,150,20);
		add(sub5);
		att.setBounds(350,500,150,20);
		add(att);
		

		submit.setBounds(300,600,100,50);
		add(submit);
		submit.addActionListener(this);
		}
		public static void main(String[] args) 
		{
		new AddStudentMarks();
		}
		public void actionPerformed(ActionEvent ar) 
		{
			
		if(ar.getSource()==submit)
		{
		this.hide();
		String name=t1.getText();
		String id= t2.getText(); 
		String msub1=sub1.getText();
		String msub2=sub2.getText();
		String msub3=sub3.getText();
		String msub4=sub4.getText();
		String msub5=sub5.getText();
		int a = Integer.parseInt(msub1);
		int b = Integer.parseInt(msub2);
		int c = Integer.parseInt(msub3);
		int d = Integer.parseInt(msub4);
		int e = Integer.parseInt(msub5);
		double mgpa;
		mgpa = (a+b+c+d+e)/50.0;
		try(FileWriter fw = new FileWriter("D:\\Coe\\studentmarks.txt", true);
    		    BufferedWriter bw = new BufferedWriter(fw);
    		    PrintWriter out = new PrintWriter(bw))
    		{
    		    out.print("STUDENT NAME: "+name);
    		    out.print("   STUDENT ID:"+id);
    		    out.print("   SUB 1: "+msub1);
    		    out.print("   SUB 2: "+msub2);
    		    out.print("   SUB 3: "+msub3);
    		    out.print("   SUB 4: "+msub4);
    		    out.print("   SUB 5: "+msub5);
    		    out.print("   GPA: "+mgpa);
    		    out.print("   Attendance: "+mgpa);
    		    
    		    
    		    //more code
    		    //out.println("more text");
    		    //more code
    		} catch (IOException f) {
    		    //exception handling left as an exercise for the reader
    		}	        
	  }
		}
		
		

}