package coe;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;  
	import java.awt.event.ActionEvent;
		import java.awt.event.ActionListener;
		import javax.swing.JFrame;
		import javax.swing.*;
		public class AddStudent extends JFrame implements ActionListener
		{
		
		JLabel l6=new JLabel("ADD STUDENT");
		JLabel l1=new JLabel("NAME");
		JLabel l2=new JLabel("STUDENT ID");
		JLabel l5 =new JLabel("CONTACT NUMBER");
		
		JLabel l4=new JLabel("GENDER");
		JTextField t1=new JTextField();
		JTextField t2=new JTextField();
		JTextField t3=new JTextField();
		JCheckBox c1=new JCheckBox("MALE");
		JCheckBox c2=new JCheckBox("FEMALE");
		ButtonGroup bg=new ButtonGroup();
		
		JButton b=new JButton("SUBMIT");
		//JPasswordField p=new JPasswordField();
		
		
		public AddStudent()
		{
		setTitle("ADD STUDENT");
		this.setLayout(null);
		this.setVisible(true);
		this.setSize(700,700);
		l6.setBounds(300,10,200,40);
		l1.setBounds(100,100,200,40);
		l2.setBounds(100,200,200,40);
		//l3.setBounds(100,300,200,40);
		l4.setBounds(100,400,200,40);
		l5.setBounds(100,300,200,40);
		add(l1);
		add(l2);
		//add(l3);
		add(l4);
		add(l6);
		add(l5);
		t1.setBounds(250,100,150,40);
		add(t1);
		t2.setBounds(250,200,150,40);
		add(t2);
		t3.setBounds(250,300,150,40);
		add(t3);
		
		c1.setBounds(250,400,100,40);
		c2.setBounds(350,400,100,40);
		add(c1);
		add(c2);
		bg.add(c1);
		bg.add(c2);
		
		b.setBounds(200,550,100,60);
		add(b);
		b.addActionListener(this);
		}
		public static void main(String[] args) 
		{
		new AddStudent();
		}
		public void actionPerformed(ActionEvent ar) 
		{
			
		if(ar.getSource()==b)
		{
		this.hide();
		String aa=t1.getText();
		String ab= t2.getText(); 
		String ac=t3.getText();
		
		try(FileWriter fw = new FileWriter("D:\\Coe\\student.txt", true);
    		    BufferedWriter bw = new BufferedWriter(fw);
    		    PrintWriter out = new PrintWriter(bw))
    		{
    		    out.print("STUDENT NAME: "+aa);
    		    out.print("   STUDENT ID:"+ab);
    		    out.print("   CONTACT NUMBER: "+ac);
    		    if(c1.isSelected()) {
    	        	out.println("   Gender: MALE");
    	        }
    	        else if(c2.isSelected()) {
    	        	out.println("   Gender: FEMALE");
    	        }
    	        else {
    	        	out.println("   Gender: other");
    	        }
    		    
    		    //more code
    		    //out.println("more text");
    		    //more code
    		} catch (IOException e) {
    		    //exception handling left as an exercise for the reader
    		}
		
	        
	  }    
		}
		
		

}