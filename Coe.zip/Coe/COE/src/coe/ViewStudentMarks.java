package coe;
import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JTextArea;

public class ViewStudentMarks {
  public static void main(String... args) {
    JFileChooser fc = new JFileChooser();
    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    JTextArea tarea = new JTextArea(10, 10);
    	  File file = new File("D:\\Coe\\studentmarks.txt");
        try {
          BufferedReader input = new BufferedReader(new InputStreamReader(
              new FileInputStream(file)));
          tarea.read(input, "READING FILE :-)");
        } catch (Exception e) {
          e.printStackTrace();
      }

    frame.getContentPane().add(tarea, BorderLayout.CENTER);
    frame.pack();
    frame.setVisible(true);
  }
}