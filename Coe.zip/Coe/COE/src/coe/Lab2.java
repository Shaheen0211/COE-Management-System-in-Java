package coe;

import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import java.awt.event.*;
import javax.swing.event.*;
public class Lab2 extends JFrame implements ActionListener
{
JLabel l1,l2,l3,l;
JTextField t1,t2;
JTextArea ta,ta1;
JButton b;
Lab2()
        {
        super("Student Form");
        l=new JLabel("Student Details");
        l1=new JLabel("Enter Number:");
        l2=new JLabel("Enter Total Marks:");
        l3=new JLabel("Enter Address:");
        t1=new JTextField(20); 
        t2=new JTextField(20);
        ta=new JTextArea("",20,20);
        ta1=new JTextArea("",20,20);
        b=new JButton("Result");

        setSize(410,450);
        setResizable(false);
        setLayout(null);

        add(l).setBounds(80,1,150,50);
        add(l1).setBounds(10,60,150,20); 
        add(t1).setBounds(150,60,200,20);
        add(l2).setBounds(10,90,150,20); 
 
        add(t2).setBounds(150,90,200,20);
        add(l3).setBounds(10,110,150,20);
        add(ta1).setBounds(150,130,200,100);
        add(b).setBounds(150,250,120,20);
        add(ta).setBounds(150,300,200,100);
        b.addActionListener(this);





        addWindowListener(new WindowAdapter(){
  public void windowClosing(WindowEvent e)
  {
   System.exit(0);
  }
 });
         }
        public void actionPerformed(ActionEvent e)
        {
         if(e.getSource()==b)

 if ( Integer.parseInt(t2.getText()) <100 )
 ta.insert("Below Average",0);
else if( Integer.parseInt(t2.getText()) >=100 && Integer.parseInt(t2.getText()) <=300)
 ta.insert("Average",0);
 
else if( Integer.parseInt(t2.getText()) >=500 && Integer.parseInt(t2.getText()) <=1000)
 ta.insert("Good",0);
         }
public static void main(String str[])
        {
        Lab2 l=new Lab2();
        l.setVisible(true);
        }
}