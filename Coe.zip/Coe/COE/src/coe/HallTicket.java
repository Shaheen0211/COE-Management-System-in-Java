package coe;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.*;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
		import java.awt.event.ActionListener;

import javax.swing.*;
		public class HallTicket extends JFrame implements ActionListener
		{
		
		JLabel l1=new JLabel("NAME");
		JLabel l2=new JLabel("ID");
		JLabel l3=new JLabel("YEAR");
		
		String languages[]={"1st year","2nd year","3rd year","4th year","Arrear"};        
	    final JComboBox cb=new JComboBox(languages);
		
		JTextField t1=new JTextField();
		JTextField t2=new JTextField();
		
		
		JButton submit=new JButton("Get Hall Ticket");
		//JPasswordField p=new JPasswordField();
		
		
		public HallTicket()
		{
		setTitle("ADD STUDENT MARKS");
		this.setLayout(null);
		this.setVisible(true);
		this.setSize(800,800);
		l1.setBounds(100,50,50,20);
		l2.setBounds(100,100,50,20);
		l3.setBounds(100,150,50,20);
		
		add(l1);
		add(l2);
		add(l3);
		
		t1.setBounds(250,50,150,40);
		add(t1);
		t2.setBounds(250,100,150,40);
		add(t2);
		
		    
	    cb.setBounds(250,150,150,40);    
	    add(cb);
		

		submit.setBounds(150,250,100,50);
		add(submit);
		submit.addActionListener(this);
		}
		public static void main(String[] args) 
		{
		new HallTicket();
		}
		public void actionPerformed(ActionEvent ar) 
		{
			
		if(ar.getSource()==submit)
		{
		this.hide();
		String name=t1.getText();
		String id= t2.getText(); 
		String data = "		SRI KRISHNA COLLEGE OF TECHNOLOGY\r\n" + 
				"\r\n" + 
				"			NAME :"+ name+
				"\r\n" + 
				"			Reg No :"+ id+
				"\r\n" + 
				"			YEAR :"+ cb.getItemAt(cb.getSelectedIndex())+"\n\n	EXAMINATION TIME TABLE\r\n" + 
				"\r\n" + 
				"DATE      	IT	CSE	ECE	EEE\r\n" + 
				"20.11.2018	SUb 1	Sub 2	Sub 3	Sub 4\r\n" + 
				"23.11.2018	SUb 1	Sub 2	Sub 3	Sub 4\r\n" + 
				"26.11.2018	SUb 1	Sub 2	Sub 3	Sub 4\r\n" + 
				"28.11.2018	SUb 1	Sub 2	Sub 3	Sub 4\r\n" + 
				"30.11.2018	SUb 1	Sub 2	Sub 3	Sub 4\r\n" + 
				"";  

		try{
			FileWriter fw = new FileWriter("D:\\Coe\\HallTicket.txt");
    		    fw.write(data);
    		    fw.close();   
    	        fw.close();
    		    ViewHall();
    		} catch (IOException f) {
    		    //exception handling left as an exercise for the reader
    		}	        
	  }
		}
		
		public void ViewHall() {
		    JFileChooser fc = new JFileChooser();
		    JFrame frame = new JFrame();
		    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		    JTextArea tarea = new JTextArea(10, 10);
		    	  File file = new File("D:\\Coe\\HallTicket.txt");
		        try {
		          BufferedReader input = new BufferedReader(new InputStreamReader(
		              new FileInputStream(file)));
		          tarea.read(input, "READING FILE :-)");
		        } catch (Exception e) {
		          e.printStackTrace();
		      }

		    frame.getContentPane().add(tarea, BorderLayout.CENTER);
		    frame.pack();
		    frame.setVisible(true);
		  }
		
		

}